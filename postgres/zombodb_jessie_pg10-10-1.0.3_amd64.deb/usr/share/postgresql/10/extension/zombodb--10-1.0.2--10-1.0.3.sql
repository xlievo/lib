DROP FUNCTION zdb.visibility_clause(myXid bigint[], myXmax bigint, myCid int, active_xids bigint[], index regclass, type text);
